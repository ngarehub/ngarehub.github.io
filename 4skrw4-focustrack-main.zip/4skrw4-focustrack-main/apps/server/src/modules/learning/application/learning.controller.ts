import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Learning, LearningDomainFacade } from '@server/modules/learning/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { LearningApplicationEvent } from './learning.application.event'
import { LearningCreateDto, LearningUpdateDto } from './learning.dto'

@Controller('/v1/learnings')
export class LearningController {
  constructor(
    private eventService: EventService,
    private learningDomainFacade: LearningDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.learningDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: LearningCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.learningDomainFacade.create(body)

    await this.eventService.emit<LearningApplicationEvent.LearningCreated.Payload>(
      LearningApplicationEvent.LearningCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:learningId')
  async findOne(
    @Param('learningId') learningId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.learningDomainFacade.findOneByIdOrFail(
      learningId,
      queryOptions,
    )

    return item
  }

  @Patch('/:learningId')
  async update(
    @Param('learningId') learningId: string,
    @Body() body: LearningUpdateDto,
  ) {
    const item = await this.learningDomainFacade.findOneByIdOrFail(learningId)

    const itemUpdated = await this.learningDomainFacade.update(
      item,
      body as Partial<Learning>,
    )
    return itemUpdated
  }

  @Delete('/:learningId')
  async delete(@Param('learningId') learningId: string) {
    const item = await this.learningDomainFacade.findOneByIdOrFail(learningId)

    await this.learningDomainFacade.delete(item)

    return item
  }
}
