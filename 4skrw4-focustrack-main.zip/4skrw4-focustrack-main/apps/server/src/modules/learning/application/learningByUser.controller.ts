import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { LearningDomainFacade } from '@server/modules/learning/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { LearningApplicationEvent } from './learning.application.event'
import { LearningCreateDto } from './learning.dto'

import { UserDomainFacade } from '../../user/domain'

@Controller('/v1/users')
export class LearningByUserController {
  constructor(
    private userDomainFacade: UserDomainFacade,

    private learningDomainFacade: LearningDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/user/:userId/learnings')
  async findManyUserId(
    @Param('userId') userId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.userDomainFacade.findOneByIdOrFail(userId)

    const items = await this.learningDomainFacade.findManyByUser(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/user/:userId/learnings')
  async createByUserId(
    @Param('userId') userId: string,
    @Body() body: LearningCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, userId }

    const item = await this.learningDomainFacade.create(valuesUpdated)

    await this.eventService.emit<LearningApplicationEvent.LearningCreated.Payload>(
      LearningApplicationEvent.LearningCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
