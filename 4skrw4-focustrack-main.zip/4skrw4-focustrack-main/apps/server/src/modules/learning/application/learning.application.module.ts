import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { LearningDomainModule } from '../domain'
import { LearningController } from './learning.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { LearningByUserController } from './learningByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, LearningDomainModule, UserDomainModule],
  controllers: [LearningController, LearningByUserController],
  providers: [],
})
export class LearningApplicationModule {}
