export namespace LearningApplicationEvent {
  export namespace LearningCreated {
    export const key = 'learning.application.learning.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
