import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { LearningDomainFacade } from './learning.domain.facade'
import { Learning } from './learning.model'

@Module({
  imports: [TypeOrmModule.forFeature([Learning]), DatabaseHelperModule],
  providers: [LearningDomainFacade, LearningDomainFacade],
  exports: [LearningDomainFacade],
})
export class LearningDomainModule {}
