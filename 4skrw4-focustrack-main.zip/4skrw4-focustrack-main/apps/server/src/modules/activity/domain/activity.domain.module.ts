import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ActivityDomainFacade } from './activity.domain.facade'
import { Activity } from './activity.model'

@Module({
  imports: [TypeOrmModule.forFeature([Activity]), DatabaseHelperModule],
  providers: [ActivityDomainFacade, ActivityDomainFacade],
  exports: [ActivityDomainFacade],
})
export class ActivityDomainModule {}
