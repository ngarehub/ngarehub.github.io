import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ActivityDomainModule } from '../domain'
import { ActivityController } from './activity.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ActivityByUserController } from './activityByUser.controller'

@Module({
  imports: [AuthenticationDomainModule, ActivityDomainModule, UserDomainModule],
  controllers: [ActivityController, ActivityByUserController],
  providers: [],
})
export class ActivityApplicationModule {}
