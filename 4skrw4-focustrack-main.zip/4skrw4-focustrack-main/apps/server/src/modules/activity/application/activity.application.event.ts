export namespace ActivityApplicationEvent {
  export namespace ActivityCreated {
    export const key = 'activity.application.activity.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
