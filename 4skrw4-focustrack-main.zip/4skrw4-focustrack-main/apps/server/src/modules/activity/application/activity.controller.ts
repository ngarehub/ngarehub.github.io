import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Activity, ActivityDomainFacade } from '@server/modules/activity/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ActivityApplicationEvent } from './activity.application.event'
import { ActivityCreateDto, ActivityUpdateDto } from './activity.dto'

@Controller('/v1/activitys')
export class ActivityController {
  constructor(
    private eventService: EventService,
    private activityDomainFacade: ActivityDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.activityDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ActivityCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.activityDomainFacade.create(body)

    await this.eventService.emit<ActivityApplicationEvent.ActivityCreated.Payload>(
      ActivityApplicationEvent.ActivityCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:activityId')
  async findOne(
    @Param('activityId') activityId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.activityDomainFacade.findOneByIdOrFail(
      activityId,
      queryOptions,
    )

    return item
  }

  @Patch('/:activityId')
  async update(
    @Param('activityId') activityId: string,
    @Body() body: ActivityUpdateDto,
  ) {
    const item = await this.activityDomainFacade.findOneByIdOrFail(activityId)

    const itemUpdated = await this.activityDomainFacade.update(
      item,
      body as Partial<Activity>,
    )
    return itemUpdated
  }

  @Delete('/:activityId')
  async delete(@Param('activityId') activityId: string) {
    const item = await this.activityDomainFacade.findOneByIdOrFail(activityId)

    await this.activityDomainFacade.delete(item)

    return item
  }
}
