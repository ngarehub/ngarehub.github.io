import { Request } from 'express'

import { Body, Controller, Get, Param, Post, Req } from '@nestjs/common'
import { RequestHelper } from '@server/helpers/request'
import { EventService } from '@server/libraries/event'
import { ReminderDomainFacade } from '@server/modules/reminder/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { ReminderApplicationEvent } from './reminder.application.event'
import { ReminderCreateDto } from './reminder.dto'

import { LearningDomainFacade } from '../../learning/domain'

@Controller('/v1/learnings')
export class ReminderByLearningController {
  constructor(
    private learningDomainFacade: LearningDomainFacade,

    private reminderDomainFacade: ReminderDomainFacade,
    private eventService: EventService,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/related/:relatedId/reminders')
  async findManyRelatedId(
    @Param('relatedId') relatedId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const parent = await this.learningDomainFacade.findOneByIdOrFail(relatedId)

    const items = await this.reminderDomainFacade.findManyByRelated(
      parent,
      queryOptions,
    )

    return items
  }

  @Post('/related/:relatedId/reminders')
  async createByRelatedId(
    @Param('relatedId') relatedId: string,
    @Body() body: ReminderCreateDto,
    @Req() request: Request,
  ) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const valuesUpdated = { ...body, relatedId }

    const item = await this.reminderDomainFacade.create(valuesUpdated)

    await this.eventService.emit<ReminderApplicationEvent.ReminderCreated.Payload>(
      ReminderApplicationEvent.ReminderCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }
}
