import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from '@server/modules/authentication/domain'
import { ReminderDomainModule } from '../domain'
import { ReminderController } from './reminder.controller'

import { UserDomainModule } from '../../../modules/user/domain'

import { ReminderByUserController } from './reminderByUser.controller'

import { LearningDomainModule } from '../../../modules/learning/domain'

import { ReminderByLearningController } from './reminderByLearning.controller'

@Module({
  imports: [
    AuthenticationDomainModule,
    ReminderDomainModule,

    UserDomainModule,

    LearningDomainModule,
  ],
  controllers: [
    ReminderController,

    ReminderByUserController,

    ReminderByLearningController,
  ],
  providers: [],
})
export class ReminderApplicationModule {}
