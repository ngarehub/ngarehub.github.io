export namespace ReminderApplicationEvent {
  export namespace ReminderCreated {
    export const key = 'reminder.application.reminder.created'

    export type Payload = {
      id: string
      userId: string
    }
  }
}
