import { Request } from 'express'

import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Req,
} from '@nestjs/common'
import { EventService } from '@server/libraries/event'
import { Reminder, ReminderDomainFacade } from '@server/modules/reminder/domain'
import { AuthenticationDomainFacade } from '@server/modules/authentication/domain'
import { RequestHelper } from '../../../helpers/request'
import { ReminderApplicationEvent } from './reminder.application.event'
import { ReminderCreateDto, ReminderUpdateDto } from './reminder.dto'

@Controller('/v1/reminders')
export class ReminderController {
  constructor(
    private eventService: EventService,
    private reminderDomainFacade: ReminderDomainFacade,
    private authenticationDomainFacade: AuthenticationDomainFacade,
  ) {}

  @Get('/')
  async findMany(@Req() request: Request) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const items = await this.reminderDomainFacade.findMany(queryOptions)

    return items
  }

  @Post('/')
  async create(@Body() body: ReminderCreateDto, @Req() request: Request) {
    const { user } = this.authenticationDomainFacade.getRequestPayload(request)

    const item = await this.reminderDomainFacade.create(body)

    await this.eventService.emit<ReminderApplicationEvent.ReminderCreated.Payload>(
      ReminderApplicationEvent.ReminderCreated.key,
      {
        id: item.id,
        userId: user.id,
      },
    )

    return item
  }

  @Get('/:reminderId')
  async findOne(
    @Param('reminderId') reminderId: string,
    @Req() request: Request,
  ) {
    const queryOptions = RequestHelper.getQueryOptions(request)

    const item = await this.reminderDomainFacade.findOneByIdOrFail(
      reminderId,
      queryOptions,
    )

    return item
  }

  @Patch('/:reminderId')
  async update(
    @Param('reminderId') reminderId: string,
    @Body() body: ReminderUpdateDto,
  ) {
    const item = await this.reminderDomainFacade.findOneByIdOrFail(reminderId)

    const itemUpdated = await this.reminderDomainFacade.update(
      item,
      body as Partial<Reminder>,
    )
    return itemUpdated
  }

  @Delete('/:reminderId')
  async delete(@Param('reminderId') reminderId: string) {
    const item = await this.reminderDomainFacade.findOneByIdOrFail(reminderId)

    await this.reminderDomainFacade.delete(item)

    return item
  }
}
