import { ColumnNumeric } from '@server/core/database'
import {
  Column,
  CreateDateColumn,
  DeleteDateColumn,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  UpdateDateColumn,
} from 'typeorm'

import { User } from '../../../modules/user/domain'

import { Learning } from '../../../modules/learning/domain'

@Entity()
export class Reminder {
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({})
  message: string

  @Column({ nullable: true })
  reminderTime?: string

  @Column({})
  userId: string

  @ManyToOne(() => User, parent => parent.reminders)
  @JoinColumn({ name: 'userId' })
  user?: User

  @Column({})
  relatedId: string

  @ManyToOne(() => Learning, parent => parent.remindersAsRelated)
  @JoinColumn({ name: 'relatedId' })
  related?: Learning

  @CreateDateColumn()
  dateCreated: string

  @UpdateDateColumn()
  dateUpdated: string

  @DeleteDateColumn()
  dateDeleted: string
}
