import { Module } from '@nestjs/common'
import { TypeOrmModule } from '@nestjs/typeorm'
import { DatabaseHelperModule } from '../../../core/database'
import { ReminderDomainFacade } from './reminder.domain.facade'
import { Reminder } from './reminder.model'

@Module({
  imports: [TypeOrmModule.forFeature([Reminder]), DatabaseHelperModule],
  providers: [ReminderDomainFacade, ReminderDomainFacade],
  exports: [ReminderDomainFacade],
})
export class ReminderDomainModule {}
