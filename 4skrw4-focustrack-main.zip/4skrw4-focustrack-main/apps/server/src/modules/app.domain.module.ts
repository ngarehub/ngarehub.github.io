import { Module } from '@nestjs/common'
import { AuthenticationDomainModule } from './authentication/domain'
import { AuthorizationDomainModule } from './authorization/domain'

import { UserDomainModule } from './user/domain'

import { NotificationDomainModule } from './notification/domain'

import { ActivityDomainModule } from './activity/domain'

import { LearningDomainModule } from './learning/domain'

import { ReminderDomainModule } from './reminder/domain'

@Module({
  imports: [
    AuthenticationDomainModule,
    AuthorizationDomainModule,
    UserDomainModule,
    NotificationDomainModule,

    ActivityDomainModule,

    LearningDomainModule,

    ReminderDomainModule,
  ],
  controllers: [],
  providers: [],
})
export class AppDomainModule {}
