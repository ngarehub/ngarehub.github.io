import { Module } from '@nestjs/common'
import { SocketModule } from '@server/libraries/socket'
import { AuthorizationDomainModule } from '@server/modules/authorization/domain'
import { NotificationDomainModule } from '../domain'

import { NotificationActivitySubscriber } from './subscribers/notification.activity.subscriber'

import { NotificationLearningSubscriber } from './subscribers/notification.learning.subscriber'

import { NotificationReminderSubscriber } from './subscribers/notification.reminder.subscriber'

@Module({
  imports: [AuthorizationDomainModule, NotificationDomainModule, SocketModule],
  providers: [
    NotificationActivitySubscriber,

    NotificationLearningSubscriber,

    NotificationReminderSubscriber,
  ],
  exports: [],
})
export class NotificationInfrastructureModule {}
