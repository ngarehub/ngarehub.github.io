'use client'

import React, { useEffect, useState } from 'react'
import { Typography, Card, Col, Row, Progress, Avatar } from 'antd'
import { BookOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ViewLearningProgressPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [learnings, setLearnings] = useState([])

  useEffect(() => {
    if (!userId) {
      enqueueSnackbar('User not found, please login.', { variant: 'error' })
      router.push('/home')
      return
    }

    const fetchLearnings = async () => {
      try {
        const userLearnings = await Api.Learning.findManyByUserId(userId, {
          includes: ['user'],
        })
        setLearnings(userLearnings)
      } catch (error) {
        enqueueSnackbar('Failed to fetch learning data.', { variant: 'error' })
      }
    }

    fetchLearnings()
  }, [userId, router])

  return (
    <PageLayout layout="full-width">
      <Title level={2}>Learning Progress</Title>
      <Text type="secondary">
        Here you can see your progress in different learning subjects.
      </Text>
      <Row gutter={[16, 16]} style={{ marginTop: 20 }}>
        {learnings?.map(learning => (
          <Col key={learning.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              title={
                <>
                  <BookOutlined /> {learning.subject}
                </>
              }
              extra={<Avatar src={learning.user?.pictureUrl} />}
              style={{ width: '100%' }}
            >
              <Text>{learning.content}</Text>
              <Progress percent={learning.progressPercentage} status="active" />
            </Card>
          </Col>
        ))}
      </Row>
    </PageLayout>
  )
}
