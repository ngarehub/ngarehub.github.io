'use client'

import { Button, Form, Input, Typography, Col, Row, Progress } from 'antd'
import { PlusCircleOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function CreateLearningEntryPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()

  const handleSubmit = async (values: any) => {
    try {
      const newLearning = await Api.Learning.createOneByUserId(userId, {
        subject: values.subject,
        content: values.content,
        progressPercentage: values.progressPercentage,
      })
      enqueueSnackbar('Learning session logged successfully!', {
        variant: 'success',
      })
      router.push('/learning')
    } catch (error) {
      enqueueSnackbar('Failed to log learning session.', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={18} md={12} lg={10} xl={8}>
          <Title level={2}>Log Learning Session</Title>
          <Text type="secondary">
            Enter the details of your learning session to track your educational
            progress.
          </Text>
          <Form form={form} layout="vertical" onFinish={handleSubmit}>
            <Form.Item
              label="Subject"
              name="subject"
              rules={[{ required: true, message: 'Please input the subject!' }]}
            >
              <Input placeholder="Subject of learning" />
            </Form.Item>
            <Form.Item label="Content" name="content">
              <Input.TextArea
                rows={4}
                placeholder="Details of what was learned"
              />
            </Form.Item>
            <Form.Item label="Progress Percentage" name="progressPercentage">
              <Progress percent={form.getFieldValue('progressPercentage')} />
              <Input
                type="number"
                placeholder="Progress in percentage"
                onChange={e =>
                  form.setFieldsValue({ progressPercentage: e.target.value })
                }
              />
            </Form.Item>
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                icon={<PlusCircleOutlined />}
              >
                Log Learning
              </Button>
            </Form.Item>
          </Form>
        </Col>
      </Row>
    </PageLayout>
  )
}
