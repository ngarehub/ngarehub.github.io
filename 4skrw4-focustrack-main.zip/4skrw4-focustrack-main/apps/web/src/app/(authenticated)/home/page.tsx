'use client'

import { useEffect, useState } from 'react'
import { Typography, Card, Col, Row, Avatar, List, Button } from 'antd'
import {
  UserOutlined,
  CalendarOutlined,
  BookOutlined,
  BellOutlined,
} from '@ant-design/icons'
const { Title, Text } = Typography
interface User {
  id: string
  email: string
  name?: string
  pictureUrl?: string
  activitys?: Activity[]
  learnings?: Learning[]
  reminders?: Reminder[]
}
interface Activity {
  id: string
  title: string
  date?: string
}
interface Learning {
  id: string
  subject: string
  progressPercentage?: number
}
interface Reminder {
  id: string
  message: string
  reminderTime?: string
}
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function HomePage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    if (userId) {
      Api.User.findOne(userId, {
        includes: ['activitys', 'learnings', 'reminders'],
      })
        .then((data: User) => setUser(data))
        .catch(error =>
          enqueueSnackbar('Failed to fetch user data', { variant: 'error' }),
        )
    }
  }, [userId])

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
      <Title level={2}>Welcome to Your Dashboard</Title>
      <Text>
        This is your main hub for tracking your activities, learning progress,
        and upcoming reminders.
      </Text>

      <Row gutter={16} style={{ marginTop: '24px' }}>
        <Col span={8}>
          <Card title="Profile" bordered={false}>
            <Avatar size={64} icon={<UserOutlined />} src={user?.pictureUrl} />
            <Title level={4} style={{ marginTop: '16px' }}>
              {user?.name}
            </Title>
            <Text>Email: {user?.email}</Text>
          </Card>
        </Col>
        <Col span={8}>
          <Card title="Upcoming Activities" bordered={false}>
            <List
              itemLayout="horizontal"
              dataSource={user?.activitys}
              renderItem={item => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<CalendarOutlined />}
                    title={item.title}
                    description={dayjs(item.date).format('MMMM D, YYYY')}
                  />
                </List.Item>
              )}
            />
            <Button
              type="primary"
              onClick={() => router.push('/activity/create')}
            >
              Add Activity
            </Button>
          </Card>
        </Col>
        <Col span={8}>
          <Card title="Learning Progress" bordered={false}>
            <List
              itemLayout="horizontal"
              dataSource={user?.learnings}
              renderItem={item => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<BookOutlined />}
                    title={item.subject}
                    description={`Progress: ${item.progressPercentage}%`}
                  />
                </List.Item>
              )}
            />
            <Button
              type="primary"
              onClick={() => router.push('/learning/create')}
            >
              Add Learning
            </Button>
          </Card>
        </Col>
      </Row>

      <Row style={{ marginTop: '24px' }}>
        <Col span={24}>
          <Card title="Reminders" bordered={false}>
            <List
              itemLayout="horizontal"
              dataSource={user?.reminders}
              renderItem={item => (
                <List.Item>
                  <List.Item.Meta
                    avatar={<BellOutlined />}
                    title={item.message}
                    description={dayjs(item.reminderTime).format(
                      'MMMM D, YYYY h:mm A',
                    )}
                  />
                </List.Item>
              )}
            />
            <Button
              type="primary"
              onClick={() => router.push('/reminder/create')}
            >
              Set Reminder
            </Button>
          </Card>
        </Col>
      </Row>
    </div>
  )
}
