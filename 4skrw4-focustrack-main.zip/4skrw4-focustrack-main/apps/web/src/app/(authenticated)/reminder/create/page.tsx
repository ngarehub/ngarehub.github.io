'use client'

import React, { useEffect, useState } from 'react'
import { Button, DatePicker, Form, Input, Select, Typography } from 'antd'
import { PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { Option } = Select
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function SetReminderPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [form] = Form.useForm()
  const [learnings, setLearnings] = useState([])

  useEffect(() => {
    const fetchLearnings = async () => {
      if (userId) {
        const user = await Api.User.findOne(userId, { includes: ['learnings'] })
        setLearnings(user.learnings || [])
      }
    }
    fetchLearnings()
  }, [userId])

  const onFinish = async values => {
    try {
      const reminder = await Api.Reminder.createOneByUserId(userId, {
        message: values.message,
        reminderTime: values.reminderTime.format(),
        relatedId: values.relatedId,
      })
      enqueueSnackbar('Reminder created successfully!', { variant: 'success' })
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to create reminder', { variant: 'error' })
    }
  }

  return (
    <PageLayout layout="full-width">
      <div style={{ maxWidth: '600px', margin: '0 auto' }}>
        <Title level={2}>Set a Reminder</Title>
        <Text>Use this form to set reminders for your learning sessions.</Text>
        <Form form={form} layout="vertical" onFinish={onFinish}>
          <Form.Item
            name="message"
            label="Reminder Message"
            rules={[
              { required: true, message: 'Please input the reminder message!' },
            ]}
          >
            <Input placeholder="Enter a reminder message" />
          </Form.Item>
          <Form.Item
            name="reminderTime"
            label="Reminder Time"
            rules={[
              { required: true, message: 'Please select the reminder time!' },
            ]}
          >
            <DatePicker showTime />
          </Form.Item>
          <Form.Item
            name="relatedId"
            label="Related Learning Session"
            rules={[
              { required: true, message: 'Please select a learning session!' },
            ]}
          >
            <Select placeholder="Select a learning session">
              {learnings?.map(learning => (
                <Option key={learning.id} value={learning.id}>
                  {learning.subject}
                </Option>
              ))}
            </Select>
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit" icon={<PlusOutlined />}>
              Set Reminder
            </Button>
          </Form.Item>
        </Form>
      </div>
    </PageLayout>
  )
}
