'use client'

import { useEffect, useState } from 'react'
import {
  Button,
  Col,
  DatePicker,
  Form,
  Input,
  List,
  Modal,
  Row,
  Typography,
} from 'antd'
import { ExclamationCircleOutlined, PlusOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
const { confirm } = Modal
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ManageRemindersPage() {
  const router = useRouter()
  const params = useParams<any>()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const { enqueueSnackbar } = useSnackbar()
  const [reminders, setReminders] = useState([])
  const [isModalVisible, setIsModalVisible] = useState(false)
  const [form] = Form.useForm()

  useEffect(() => {
    if (userId) {
      fetchReminders()
    }
  }, [userId])

  const fetchReminders = async () => {
    try {
      const data = await Api.Reminder.findManyByUserId(userId, {
        includes: ['related'],
      })
      setReminders(data)
    } catch (error) {
      enqueueSnackbar('Failed to fetch reminders', { variant: 'error' })
    }
  }

  const handleCreateReminder = async values => {
    try {
      await Api.Reminder.createOneByUserId(userId, {
        message: values.message,
        reminderTime: values.reminderTime.format(),
        relatedId: values.relatedId,
      })
      enqueueSnackbar('Reminder created successfully', { variant: 'success' })
      fetchReminders()
      setIsModalVisible(false)
      form.resetFields()
    } catch (error) {
      enqueueSnackbar('Failed to create reminder', { variant: 'error' })
    }
  }

  const showDeleteConfirm = reminderId => {
    confirm({
      title: 'Are you sure delete this reminder?',
      icon: <ExclamationCircleOutlined />,
      content: 'This action cannot be undone',
      async onOk() {
        await Api.Reminder.deleteOne(reminderId)
        enqueueSnackbar('Reminder deleted successfully', { variant: 'success' })
        fetchReminders()
      },
      onCancel() {},
    })
  }

  const showModal = () => {
    setIsModalVisible(true)
  }

  const handleCancel = () => {
    setIsModalVisible(false)
  }

  return (
    <PageLayout layout="full-width">
      <Row justify="center">
        <Col xs={24} sm={20} md={16} lg={12}>
          <Title level={2}>Manage Reminders</Title>
          <Text>
            Here you can add, view, and delete reminders for your activities and
            learning sessions.
          </Text>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={showModal}
            style={{ marginBottom: 16 }}
          >
            Add Reminder
          </Button>
          <List
            itemLayout="horizontal"
            dataSource={reminders}
            renderItem={item => (
              <List.Item
                actions={[
                  <a
                    key="list-loadmore-edit"
                    onClick={() => showDeleteConfirm(item.id)}
                  >
                    delete
                  </a>,
                ]}
              >
                <List.Item.Meta
                  title={item.message}
                  description={`Reminder Time: ${dayjs(item.reminderTime).format('YYYY-MM-DD HH:mm')}`}
                />
              </List.Item>
            )}
          />
        </Col>
      </Row>
      <Modal
        title="Create a new Reminder"
        visible={isModalVisible}
        onCancel={handleCancel}
        footer={null}
      >
        <Form form={form} layout="vertical" onFinish={handleCreateReminder}>
          <Form.Item
            name="message"
            label="Message"
            rules={[
              { required: true, message: 'Please input the reminder message!' },
            ]}
          >
            <Input />
          </Form.Item>
          <Form.Item
            name="reminderTime"
            label="Reminder Time"
            rules={[
              { required: true, message: 'Please select a reminder time!' },
            ]}
          >
            <DatePicker showTime />
          </Form.Item>
          <Form.Item
            name="relatedId"
            label="Related Learning or Activity ID"
            rules={[
              { required: true, message: 'Please input the related ID!' },
            ]}
          >
            <Input />
          </Form.Item>
          <Button type="primary" htmlType="submit">
            Create Reminder
          </Button>
        </Form>
      </Modal>
    </PageLayout>
  )
}
