'use client'

import { useEffect, useState } from 'react'
import { Typography, List, Button, Space, Card } from 'antd'
import { EditOutlined, DeleteOutlined } from '@ant-design/icons'
const { Title, Text } = Typography
import { useAuthentication } from '@web/modules/authentication'
import dayjs from 'dayjs'
import { useSnackbar } from 'notistack'
import { useRouter, useParams } from 'next/navigation'
import { Api, Model } from '@web/domain'
import { PageLayout } from '@web/layouts/Page.layout'

export default function ViewActivitiesPage() {
  const router = useRouter()
  const { enqueueSnackbar } = useSnackbar()
  const authentication = useAuthentication()
  const userId = authentication.user?.id
  const [activities, setActivities] = useState([])

  useEffect(() => {
    if (userId) {
      Api.Activity.findManyByUserId(userId, { includes: ['user'] })
        .then(setActivities)
        .catch(() =>
          enqueueSnackbar('Failed to fetch activities', { variant: 'error' }),
        )
    }
  }, [userId])

  const handleDelete = async activityId => {
    try {
      await Api.Activity.deleteOne(activityId)
      setActivities(activities.filter(activity => activity.id !== activityId))
      enqueueSnackbar('Activity deleted successfully', { variant: 'success' })
    } catch {
      enqueueSnackbar('Failed to delete activity', { variant: 'error' })
    }
  }

  const handleEdit = activityId => {
    router.push(`/activity/edit/${activityId}`)
  }

  return (
    <PageLayout layout="full-width">
      <Title level={2}>Your Activities</Title>
      <Text type="secondary">Here you can manage all your activities.</Text>
      <List
        itemLayout="horizontal"
        dataSource={activities}
        renderItem={activity => (
          <List.Item>
            <Card
              title={activity.title}
              extra={
                <Space>
                  <Button
                    icon={<EditOutlined />}
                    onClick={() => handleEdit(activity.id)}
                  >
                    Edit
                  </Button>
                  <Button
                    icon={<DeleteOutlined />}
                    onClick={() => handleDelete(activity.id)}
                  >
                    Delete
                  </Button>
                </Space>
              }
            >
              <Text>{activity.description}</Text>
              <br />
              <Text type="secondary">
                {activity.date} at {activity.time}
              </Text>
            </Card>
          </List.Item>
        )}
      />
    </PageLayout>
  )
}
