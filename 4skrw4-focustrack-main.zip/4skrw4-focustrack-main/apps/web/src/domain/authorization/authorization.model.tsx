export enum AuthorizationType {
  USER_VERIFICATION = 'user.verification',
}

export class AuthorizationRole {
  name: string
}
