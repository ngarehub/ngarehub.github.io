import { Notification } from '../notification'

import { Activity } from '../activity'

import { Learning } from '../learning'

import { Reminder } from '../reminder'

export enum UserStatus {
  CREATED = 'CREATED',
  VERIFIED = 'VERIFIED',
}
export class User {
  id: string
  email: string
  status: UserStatus
  name: string
  pictureUrl: string
  password: string
  dateCreated: string
  dateUpdated: string
  notifications?: Notification[]

  googleCalendarSyncToken?: string

  activitys?: Activity[]

  learnings?: Learning[]

  reminders?: Reminder[]
}
