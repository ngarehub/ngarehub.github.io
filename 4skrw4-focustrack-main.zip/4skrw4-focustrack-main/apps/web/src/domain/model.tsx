import { AuthorizationRole as AuthorizationRoleModel } from './authorization/authorization.model'

import { User as UserModel } from './user/user.model'

import { Notification as NotificationModel } from './notification/notification.model'

import { Activity as ActivityModel } from './activity/activity.model'

import { Learning as LearningModel } from './learning/learning.model'

import { Reminder as ReminderModel } from './reminder/reminder.model'

export namespace Model {
  export class AuthorizationRole extends AuthorizationRoleModel {}

  export class User extends UserModel {}

  export class Notification extends NotificationModel {}

  export class Activity extends ActivityModel {}

  export class Learning extends LearningModel {}

  export class Reminder extends ReminderModel {}
}
