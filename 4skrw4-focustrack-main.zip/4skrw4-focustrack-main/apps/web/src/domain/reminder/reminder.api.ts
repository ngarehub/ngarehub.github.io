import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Reminder } from './reminder.model'

export class ReminderApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Reminder>,
  ): Promise<Reminder[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/reminders${buildOptions}`)
  }

  static findOne(
    reminderId: string,
    queryOptions?: ApiHelper.QueryOptions<Reminder>,
  ): Promise<Reminder> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/reminders/${reminderId}${buildOptions}`)
  }

  static createOne(values: Partial<Reminder>): Promise<Reminder> {
    return HttpService.api.post(`/v1/reminders`, values)
  }

  static updateOne(
    reminderId: string,
    values: Partial<Reminder>,
  ): Promise<Reminder> {
    return HttpService.api.patch(`/v1/reminders/${reminderId}`, values)
  }

  static deleteOne(reminderId: string): Promise<void> {
    return HttpService.api.delete(`/v1/reminders/${reminderId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Reminder>,
  ): Promise<Reminder[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/reminders${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Reminder>,
  ): Promise<Reminder> {
    return HttpService.api.post(`/v1/users/user/${userId}/reminders`, values)
  }

  static findManyByRelatedId(
    relatedId: string,
    queryOptions?: ApiHelper.QueryOptions<Reminder>,
  ): Promise<Reminder[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/learnings/related/${relatedId}/reminders${buildOptions}`,
    )
  }

  static createOneByRelatedId(
    relatedId: string,
    values: Partial<Reminder>,
  ): Promise<Reminder> {
    return HttpService.api.post(
      `/v1/learnings/related/${relatedId}/reminders`,
      values,
    )
  }
}
