import { User } from '../user'

import { Learning } from '../learning'

export class Reminder {
  id: string

  message: string

  reminderTime?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User

  relatedId: string

  related?: Learning
}
