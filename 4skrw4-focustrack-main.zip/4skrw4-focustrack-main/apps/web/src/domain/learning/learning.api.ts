import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Learning } from './learning.model'

export class LearningApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Learning>,
  ): Promise<Learning[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/learnings${buildOptions}`)
  }

  static findOne(
    learningId: string,
    queryOptions?: ApiHelper.QueryOptions<Learning>,
  ): Promise<Learning> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/learnings/${learningId}${buildOptions}`)
  }

  static createOne(values: Partial<Learning>): Promise<Learning> {
    return HttpService.api.post(`/v1/learnings`, values)
  }

  static updateOne(
    learningId: string,
    values: Partial<Learning>,
  ): Promise<Learning> {
    return HttpService.api.patch(`/v1/learnings/${learningId}`, values)
  }

  static deleteOne(learningId: string): Promise<void> {
    return HttpService.api.delete(`/v1/learnings/${learningId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Learning>,
  ): Promise<Learning[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/learnings${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Learning>,
  ): Promise<Learning> {
    return HttpService.api.post(`/v1/users/user/${userId}/learnings`, values)
  }
}
