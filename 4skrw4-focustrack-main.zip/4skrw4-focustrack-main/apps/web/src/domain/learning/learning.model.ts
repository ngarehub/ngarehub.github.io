import { User } from '../user'

import { Reminder } from '../reminder'

export class Learning {
  id: string

  subject: string

  content?: string

  progressPercentage?: number

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User

  remindersAsRelated?: Reminder[]
}
