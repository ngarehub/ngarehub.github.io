import { User } from '../user'

export class Activity {
  id: string

  title: string

  description?: string

  date?: string

  time?: string

  googleCalendarEventId?: string

  dateCreated: string

  dateDeleted: string

  dateUpdated: string

  userId: string

  user?: User
}
