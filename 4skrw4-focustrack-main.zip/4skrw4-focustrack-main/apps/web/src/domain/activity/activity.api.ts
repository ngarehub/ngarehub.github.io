import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Activity } from './activity.model'

export class ActivityApi {
  static findMany(
    queryOptions?: ApiHelper.QueryOptions<Activity>,
  ): Promise<Activity[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/activitys${buildOptions}`)
  }

  static findOne(
    activityId: string,
    queryOptions?: ApiHelper.QueryOptions<Activity>,
  ): Promise<Activity> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/activitys/${activityId}${buildOptions}`)
  }

  static createOne(values: Partial<Activity>): Promise<Activity> {
    return HttpService.api.post(`/v1/activitys`, values)
  }

  static updateOne(
    activityId: string,
    values: Partial<Activity>,
  ): Promise<Activity> {
    return HttpService.api.patch(`/v1/activitys/${activityId}`, values)
  }

  static deleteOne(activityId: string): Promise<void> {
    return HttpService.api.delete(`/v1/activitys/${activityId}`)
  }

  static findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Activity>,
  ): Promise<Activity[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/activitys${buildOptions}`,
    )
  }

  static createOneByUserId(
    userId: string,
    values: Partial<Activity>,
  ): Promise<Activity> {
    return HttpService.api.post(`/v1/users/user/${userId}/activitys`, values)
  }
}
